import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, Alert } from "react-native";
import { useRouter } from "expo-router";
import { supabase } from "../lib/supabase";
import { Button } from "@rneui/themed";

const RegisterScreen = () => {
  const router = useRouter();
  const [email, setEmail] = useState(""); // Certifique-se de inicializar o email
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (password !== confirmPassword) {
      alert("As senhas não conferem.");
      return;
    }
  
    setLoading(true);
    try {
      // Cria o usuário no Supabase
      const { error } = await supabase.auth.signUp({
        email: email,
        password: password,
      });
  
      if (error) {
        alert("Erro ao cadastrar: " + error.message);
      } else {
        alert("Cadastro realizado com sucesso! Verifique seu email para confirmar.");
        router.push("/login");
      }
    } catch (err) {
      alert("Erro inesperado. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cadastro</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail} // Certifique-se de vincular o estado
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TextInput
        style={styles.input}
        placeholder="Confirme a Senha"
        secureTextEntry
        value={confirmPassword}
        onChangeText={setConfirmPassword}
      />
      <Button
        title={loading ? "Carregando..." : "Cadastrar"}
        onPress={handleRegister}
        disabled={loading}
      />
      <Text
        style={styles.link}
        onPress={() => router.push("/login")}
      >
        Já tem uma conta? Faça login
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
  },
  input: {
    width: "100%",
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
  },
  link: {
    color: "#1e90ff",
    marginTop: 16,
  },
});

export default RegisterScreen;
