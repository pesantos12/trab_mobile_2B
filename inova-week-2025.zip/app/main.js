import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, FlatList } from "react-native";
import { supabase } from "../lib/supabase";

export default function Main() {
  const [groups, setGroups] = useState([]); // Estado para armazenar os grupos
  const [loading, setLoading] = useState(true); // Estado de carregamento

  // Função para buscar os grupos no Supabase
  const fetchGroups = async () => {
    try {
      const { data, error } = await supabase
        .from("groups") // Nome da tabela no Supabase
        .select("*"); // Seleciona todos os campos

      if (error) {
        console.error("Erro ao buscar grupos:", error.message);
      } else {
        setGroups(data); // Armazena os dados no estado
      }
    } catch (err) {
      console.error("Erro inesperado:", err.message);
    } finally {
      setLoading(false); // Finaliza o carregamento
    }
  };

  // UseEffect para buscar os dados ao carregar a tela
  useEffect(() => {
    fetchGroups();
  }, []);

  // Função para renderizar cada card
  const renderGroupCard = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.title}>{item.name}</Text>
      <Text style={styles.summary}>{item.summary}</Text>
      <Text style={styles.members}>Integrantes: {item.members.join(", ")}</Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loading}>
        <Text>Carregando...</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={groups} // Dados dos grupos
      renderItem={renderGroupCard} // Função para renderizar cada card
      keyExtractor={(item) => item.id.toString()} // Chave única para cada item
      contentContainerStyle={styles.container}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 2,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },
  summary: {
    fontSize: 14,
    color: "#666",
    marginBottom: 8,
  },
  members: {
    fontSize: 14,
    color: "#333",
  },
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
