import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, Alert } from "react-native";
import { useRouter } from "expo-router";
import { supabase } from "../lib/supabase";
import { Button } from "@rneui/themed";

const ForgotPasswordScreen = () => {
  const router = useRouter();
  const [email, setEmail] = useState(""); // Estado para o email
  const [loading, setLoading] = useState(false); // Inicialize o estado loading

  const handlePasswordReset = async () => {
    setLoading(true); // Indica que a solicitação está em andamento
    try {
      // Solicita a redefinição de senha
      const { error } = await supabase.auth.resetPasswordForEmail(email);

      if (error) {
        alert("Erro ao solicitar redefinição de senha: " + error.message);
      } else {
        alert("Se o email estiver cadastrado, enviaremos as instruções para redefinição.");
        router.push("/login");
      }
    } catch (err) {
      alert("Erro inesperado. Tente novamente.");
    } finally {
      setLoading(false); // Restaura o estado loading após a operação
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Esqueci Minha Senha</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />
      <Button
        title={loading ? "Enviando..." : "Enviar"}
        onPress={handlePasswordReset}
        disabled={loading} // Desativa o botão durante o envio
      />
      <Text
        style={styles.link}
        onPress={() => router.push("/login")}
      >
        Voltar para Login
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
  },
  input: {
    width: "100%",
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
  },
  link: {
    color: "#1e90ff",
    marginTop: 16,
  },
});

export default ForgotPasswordScreen;
